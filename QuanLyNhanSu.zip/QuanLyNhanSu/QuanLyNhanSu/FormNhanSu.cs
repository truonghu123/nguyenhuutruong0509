﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyNhanSu
{
    public partial class FormNhanSu : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-HAFTC417\MAYCUATRUONG;Initial Catalog=QuanLyNhanSu;Integrated Security=True");

        public FormNhanSu()
        {
            InitializeComponent();
            dgv_danhsach.ContextMenuStrip = contextMenuStrip1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LoadNhanVien()
        {
            string query = "SELECT * FROM NHANVIEN";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv_danhsach.DataSource = dt;
        }

        private void LoadPhongBan()
        {
            string query = "SELECT * FROM PHONGBAN";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cb_phongban.DataSource = dt;
            cb_phongban.DisplayMember = "TenPhongBan";
            cb_phongban.ValueMember = "MaPhongBan";
            cb_phongban.SelectedIndex = -1;
        }

        private void FormNhanSu_Load(object sender, EventArgs e)
        {

            LoadPhongBan(); 
            LoadNhanVien();
        }

        private void dgv_danhsach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i >= 0)
            {
                txt_msnv.Text = dgv_danhsach.Rows[i].Cells["MaNV"].Value.ToString();
                txt_hoten.Text = dgv_danhsach.Rows[i].Cells["HoTen"].Value.ToString();
                dtp_ngay.Value = Convert.ToDateTime(dgv_danhsach.Rows[i].Cells["NgayVaoLam"].Value);
                cb_phongban.SelectedValue = dgv_danhsach.Rows[i].Cells["MaPhongBan"].Value.ToString();
            }
        }

        private void cb_phongban_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_phongban.SelectedIndex != -1)
            {
                string maPB = cb_phongban.SelectedValue.ToString();
                string query = "SELECT * FROM NHANVIEN WHERE MaPhongBan = @MaPB";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                da.SelectCommand.Parameters.AddWithValue("@MaPB", maPB);

                DataTable dt = new DataTable();
                da.Fill(dt);
                dgv_danhsach.DataSource = dt;
            }
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO NHANVIEN (MaNV, HoTen, NgayVaoLam, MaPhongBan) VALUES (@MaNV, @HoTen, @Ngay, @PB)", conn);
            cmd.Parameters.AddWithValue("@MaNV", txt_msnv.Text);
            cmd.Parameters.AddWithValue("@HoTen", txt_hoten.Text);
            cmd.Parameters.AddWithValue("@Ngay", dtp_ngay.Value);
            cmd.Parameters.AddWithValue("@PB", cb_phongban.SelectedValue);

            if (cmd.ExecuteNonQuery() > 0)
                MessageBox.Show("Đã thêm nhân viên!");
            else
                MessageBox.Show("Thêm thất bại!");

            LoadNhanVien();
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlCommand cmd = new SqlCommand("UPDATE NHANVIEN SET HoTen=@HoTen, NgayVaoLam=@Ngay, MaPhongBan=@PB WHERE MaNV=@MaNV", conn);
            cmd.Parameters.AddWithValue("@MaNV", txt_msnv.Text);
            cmd.Parameters.AddWithValue("@HoTen", txt_hoten.Text);
            cmd.Parameters.AddWithValue("@Ngay", dtp_ngay.Value);
            cmd.Parameters.AddWithValue("@PB", cb_phongban.SelectedValue);

            if (cmd.ExecuteNonQuery() > 0)
                MessageBox.Show("Đã cập nhật!");
            else
                MessageBox.Show("Không tìm thấy nhân viên!");

            LoadNhanVien();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM NHANVIEN WHERE MaNV=@MaNV", conn);
            cmd.Parameters.AddWithValue("@MaNV", txt_msnv.Text);

            if (cmd.ExecuteNonQuery() > 0)
                MessageBox.Show("Đã xóa!");
            else
                MessageBox.Show("Không tìm thấy nhân viên!");

            LoadNhanVien();
        }
    }
}
