﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSACH
{
    public partial class frmSach : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-HAFTC417\MAYCUATRUONG;Initial Catalog=QLSACH;Integrated Security=True"); 
        public frmSach()
        {
            InitializeComponent();
        }
        private void LoadTheLoai()
        {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM THELOAI", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cb_theloai.DataSource = dt;
                cb_theloai.DisplayMember = "TenTL";
                cb_theloai.ValueMember = "MaTL";
        }   

        private void LoadDocGia()
        {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM DOCGIA", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                DataRow row = dt.NewRow();
                row["MaDG"] = DBNull.Value;
                row["HoTen"] = "-- Chưa mượn --";
                dt.Rows.InsertAt(row, 0);

                cb_docgia.DataSource = dt;
                cb_docgia.DisplayMember = "HoTen";
                cb_docgia.ValueMember = "MaDG";
        }

        private void LoadSach()
        {
            SqlDataAdapter da = new SqlDataAdapter(@"
            SELECT S.MaSach, S.TenSach, S.TacGia, T.TenTL, D.HoTen 
            FROM SACH S
            JOIN THELOAI T ON S.MaTL = T.MaTL
            LEFT JOIN DOCGIA D ON S.MaDG = D.MaDG", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgv_danhsach.DataSource = dt;
        }

        private void frmSach_Load(object sender, EventArgs e)
        {
            LoadTheLoai();
            LoadDocGia();
            LoadSach();
        }

        private void dgv_danhsach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_danhsach.Rows[e.RowIndex];

                txt_masach.Text = row.Cells["MaSach"].Value.ToString();
                txt_tensach.Text = row.Cells["TenSach"].Value.ToString();
                txt_tacgia.Text = row.Cells["TacGia"].Value.ToString();
                cb_theloai.Text = row.Cells["TenTL"].Value.ToString();
                cb_docgia.Text = row.Cells["HoTen"].Value?.ToString() ?? "-- Chưa mượn --";
            }
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO SACH (MaSach, TenSach, TacGia, MaTL, MaDG) VALUES (@Ma, @Ten, @TacGia, @MaTL, NULL)";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Ma", txt_masach.Text);
                cmd.Parameters.AddWithValue("@Ten", txt_tensach.Text);
                cmd.Parameters.AddWithValue("@TacGia", txt_tacgia.Text);
                cmd.Parameters.AddWithValue("@MaTL", cb_theloai.SelectedValue);

                conn.Open(); cmd.ExecuteNonQuery(); conn.Close();
            }
            LoadSach(); MessageBox.Show("Đã thêm!");
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE SACH SET TenSach=@Ten, TacGia=@TacGia, MaTL=@MaTL WHERE MaSach=@Ma";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Ten", txt_tensach.Text);
                cmd.Parameters.AddWithValue("@TacGia", txt_tacgia.Text);
                cmd.Parameters.AddWithValue("@MaTL", cb_theloai.SelectedValue);
                cmd.Parameters.AddWithValue("@Ma", txt_masach.Text);

                conn.Open(); cmd.ExecuteNonQuery(); conn.Close();
            }
            LoadSach(); MessageBox.Show("Đã sửa!");
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM SACH WHERE MaSach=@Ma AND MaDG IS NULL";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Ma", txt_masach.Text);
                conn.Open(); int kq = cmd.ExecuteNonQuery(); conn.Close();

                MessageBox.Show(kq > 0 ? "Đã xóa!" : "Sách đang mượn!");
            }
            LoadSach();
        }

        private void btn_ganmuon_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE SACH SET MaDG=@MaDG WHERE MaSach=@Ma";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Ma", txt_masach.Text);
                var value = cb_docgia.SelectedIndex == 0 ? (object)DBNull.Value : cb_docgia.SelectedValue;
                cmd.Parameters.AddWithValue("@MaDG", value);

                conn.Open(); cmd.ExecuteNonQuery(); conn.Close();
            }
            LoadSach(); MessageBox.Show("Đã cập nhật mượn!");
        }
    }
}
