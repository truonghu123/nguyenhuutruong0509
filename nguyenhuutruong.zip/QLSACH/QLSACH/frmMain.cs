﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSACH
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private frmSach Form;
        private void quảnLýSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form = new frmSach();
            Form.MdiParent = this;
            Form.Show();
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form.Close();
        }
    }
}
