﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBANHANG
{
    public partial class frm_SanPham : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-HAFTC417\MAYCUATRUONG;Initial Catalog=QLBANHANG;Integrated Security=True"); 
        public frm_SanPham()
        {
            InitializeComponent();
        }

        private void LoadDanhMuc()
        {
            string sql = "SELECT * FROM DANHMUC";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cb_danhmuc.DataSource = dt;
            cb_danhmuc.DisplayMember = "TenDMSP";
            cb_danhmuc.ValueMember = "MaDM";
            cb_danhmuc.SelectedIndex = -1;
        }
        private void LoadSanPham()
        {
            string sql = @"SELECT MaSP, MaDM, TenSP, NgaySX, DonGia, HinhAnh FROM SANPHAM ORDER BY NgaySX DESC";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv_danhsach.DataSource = dt;
            dgv_danhsach.Columns["NgaySX"].DefaultCellStyle.Format = "dd/MM/yyyy";
        }


        private void frm_SanPham_Load(object sender, EventArgs e)
        {
            LoadDanhMuc();
            LoadSanPham();
        }

        private void dgv_danhsach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_danhsach.Rows[e.RowIndex];
                txt_ma.Text = row.Cells["MaSP"].Value.ToString();
                cb_danhmuc.SelectedValue = (int)row.Cells["MaDM"].Value;
                txt_ten.Text = row.Cells["TenSP"].Value.ToString();
                dtp_ngay.Value = Convert.ToDateTime(row.Cells["NgaySX"].Value);
                txt_dongia.Text = row.Cells["DonGia"].Value.ToString();
                string imagePath = row.Cells["HinhAnh"].Value.ToString();
                if (File.Exists(imagePath))
                {
                    pic_anh.Image = Image.FromFile(imagePath);
                }
                else
                {
                    pic_anh.Image = null;
                }
            }
        }

        private string selectedImagePath = "";

        private void pic_anh_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.png;*.bmp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                selectedImagePath = ofd.FileName;
                pic_anh.Image = Image.FromFile(selectedImagePath);
            }
        }

        
        private void btn_them_Click(object sender, EventArgs e)
        {
           
            string sql = "INSERT INTO SANPHAM (MaSP, MaDM, TenSP, NgaySX, DonGia, HinhAnh) VALUES (@MaSP, @MaDM, @TenSP, @NgaySX, @DonGia, @HinhAnh)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@MaSP", txt_ma.Text.Trim());
            cmd.Parameters.AddWithValue("@MaDM", cb_danhmuc.SelectedValue);
            cmd.Parameters.AddWithValue("@TenSP", txt_ten.Text.Trim());
            cmd.Parameters.AddWithValue("@NgaySX", dtp_ngay.Value);
            cmd.Parameters.AddWithValue("@DonGia", decimal.Parse(txt_dongia.Text));
            cmd.Parameters.AddWithValue("@HinhAnh", selectedImagePath);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            LoadSanPham();
            MessageBox.Show("Đã thêm sản phẩm.");
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE SANPHAM SET MaDM=@MaDM, TenSP=@TenSP, NgaySX=@NgaySX, DonGia=@DonGia, HinhAnh=@HinhAnh WHERE MaSP=@MaSP";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@MaSP", txt_ma.Text.Trim());
            cmd.Parameters.AddWithValue("@MaDM", cb_danhmuc.SelectedValue);
            cmd.Parameters.AddWithValue("@TenSP", txt_ten.Text.Trim());
            cmd.Parameters.AddWithValue("@NgaySX", dtp_ngay.Value);
            cmd.Parameters.AddWithValue("@DonGia", decimal.Parse(txt_dongia.Text));
            cmd.Parameters.AddWithValue("@HinhAnh", selectedImagePath);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            LoadSanPham();
            MessageBox.Show("Đã cập nhật sản phẩm.");
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn xóa?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string sql = "DELETE FROM SANPHAM WHERE MaSP=@MaSP";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MaSP", txt_ma.Text.Trim());
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                LoadSanPham();
                MessageBox.Show("Đã xóa sản phẩm.");
            }
        }
    }
}
