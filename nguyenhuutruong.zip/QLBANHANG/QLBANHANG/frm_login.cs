﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QLBANHANG
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }
        string connectionString = "Data Source=LAPTOP-HAFTC417\\MAYCUATRUONG;Initial Catalog=QLBANHANG;Integrated Security=True;";

        private void frm_login_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms.Count == 1)
                Application.Exit();
        }

        private void btn_dangnhap_Click_1(object sender, EventArgs e)
        {
            string user = txt_username.Text.Trim();
            string pass = txt_password.Text.Trim();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM [USER] WHERE UserName = @user AND Password = @pass";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", user);
                cmd.Parameters.AddWithValue("@pass", pass);

                conn.Open();
                int count = (int)cmd.ExecuteScalar();

                if (count == 1)
                {
                    this.Hide(); 
                    frm_main frm = new frm_main();
                    frm.ShowDialog(); 
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
