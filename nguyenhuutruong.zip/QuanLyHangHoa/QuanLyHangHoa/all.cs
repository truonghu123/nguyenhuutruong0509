﻿using QuanLyHangHoa;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System;

//1.MỞ FORM CON
private frm_SanPham Form;
private void openSanPhamToolStripMenuItem_Click(object sender, EventArgs e)
{
    Form = new frm_SanPham();
    Form.MdiParent = this;
    Form.Show();
}

private void closeSanPhamToolStripMenuItem_Click(object sender, EventArgs e)
{
    Form.Close();
}
//2.KẾT NỐI DB
SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-HAFTC417\MAYCUATRUONG;Initial Catalog=QuanLyHangHoa;Integrated Security=True");

//3.LOAD DATA
private void LoadData()
{
    string query = "SELECT * FROM SANPHAM";
    SqlDataAdapter da = new SqlDataAdapter(query, conn);
    DataTable dt = new DataTable();
    da.Fill(dt);
    dgv_danhsach.DataSource = dt;
}
//4.LOAD DANH MUC
private void LoadHangSX()
{
    string query = "SELECT * FROM HANGSX";
    SqlDataAdapter da = new SqlDataAdapter(query, conn);
    DataTable dt = new DataTable();
    da.Fill(dt);
    cb_hang.DataSource = dt;
    cb_hang.DisplayMember = "TenHang";
    cb_hang.ValueMember = "MaNSX";
    cb_hang.SelectedIndex = -1;
}
//5.LOAD NAM
private void dtp_ngay_ValueChanged(object sender, EventArgs e)
{
    int NgaySX = dtp_ngay.Value.Year;
    txt_nam.Text = (NgaySX + 2).(ToString);
}
//6.LOAD TRANG
private void frm_SanPham_Load(object sender, EventArgs e)
{
    LoadData();
    LoadHangSX();
    dtp_ngay.ValueChanged += dtp_ngay_ValueChanged;
}
//7.CHỌN SẢN PHẨM
private void dgv_danhsach_CellClick(object sender, DataGridViewCellEventArgs e)
{
    if (e.RowIndex >= 0)
    {
        DataGridViewRow row = dgv_danhsach.Rows[e.RowIndex];


        txt_masp.Text = row.Cells["MaSP"].Value.ToString();
        txt_tensp.Text = row.Cells["TenSP"].Value.ToString();
        txt_dongia.Text = row.Cells["DonGia"].Value.ToString();
        cb_hang.SelectedValue = row.Cells["MaNSX"].Value.ToString();
        dtp_ngay.Value = Convert.ToDateTime(row.Cells["NgaySX"].Value);

        int NgaySX = dtp_ngay.Value.Year;
        txt_nam.Text = (NgaySX + 2).ToString();
    }
}
//8.THÊM / SỬA / XÓA
private void btn_them_Click(object sender, EventArgs e)
{
    if (conn.State == ConnectionState.Closed)
        conn.Open();

    SqlCommand cmd = new SqlCommand("INSERT INTO SANPHAM (MaSP, TenSP, NgaySX, DonGia, MaNSX) VALUES (@MaSP, @TenSP, @NgaySX, @DonGia, @MaNSX)", conn);
    cmd.Parameters.AddWithValue("@MaSP", txt_masp.Text);
    cmd.Parameters.AddWithValue("@TenSP", txt_tensp.Text);
    cmd.Parameters.AddWithValue("@NgaySX", dtp_ngay.Value);
    cmd.Parameters.AddWithValue("@DonGia", decimal.Parse(txt_dongia.Text));
    cmd.Parameters.AddWithValue("@MaNSX", cb_hang.SelectedValue);

    if (cmd.ExecuteNonQuery() > 0)
        MessageBox.Show("Đã thêm sản phẩm!");
    else
        MessageBox.Show("Thêm thất bại!");

    conn.Close();
    LoadData();
}

private void btn_sua_Click(object sender, EventArgs e)
{
    if (conn.State == ConnectionState.Closed)
        conn.Open();

    SqlCommand cmd = new SqlCommand("UPDATE SANPHAM SET TenSP=@TenSP, NgaySX=@NgaySX, DonGia=@DonGia, MaNSX=@MaNSX WHERE MaSP=@MaSP", conn);
    cmd.Parameters.AddWithValue("@MaSP", txt_masp.Text);
    cmd.Parameters.AddWithValue("@TenSP", txt_tensp.Text);
    cmd.Parameters.AddWithValue("@NgaySX", dtp_ngay.Value);
    cmd.Parameters.AddWithValue("@DonGia", decimal.Parse(txt_dongia.Text));
    cmd.Parameters.AddWithValue("@MaNSX", cb_hang.SelectedValue);

    if (cmd.ExecuteNonQuery() > 0)
        MessageBox.Show("Đã cập nhật sản phẩm!");
    else
        MessageBox.Show("Cập nhật thất bại!");

    conn.Close();
    LoadData();
}

private void btn_xoa_Click(object sender, EventArgs e)
{
    if (conn.State == ConnectionState.Closed)
        conn.Open();

    SqlCommand cmd = new SqlCommand("DELETE FROM SANPHAM WHERE MaSP=@MaSP", conn);
    cmd.Parameters.AddWithValue("@MaSP", txt_masp.Text);

    if (cmd.ExecuteNonQuery() > 0)
        MessageBox.Show("Đã xóa sản phẩm!");
    else
        MessageBox.Show("Xóa thất bại!");

    conn.Close();
    LoadData();
}
//9.KHÁC
private void btn_tim_Click(object sender, EventArgs e)
{
    using (SqlConnection conn = new SqlConnection(connectionString))
    {
        conn.Open();
        string sql = "SELECT * FROM CUAHANG WHERE TenHang LIKE @TuKhoa";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@TuKhoa", "%" + txt_tim.Text + "%");
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        dgv_danhsach.DataSource = dt;
        txt_dem.Text = dt.Rows.Count.ToString();
    }
}









CREATE DATABASE QuanLyHangHoa;
GO

USE QuanLyHangHoa;
GO

-- Bảng HANGSX
CREATE TABLE HANGSX (
    MaNSX INT PRIMARY KEY,
    TenHang NVARCHAR(100)
);

--Bảng SANPHAM
CREATE TABLE SANPHAM (
    MaSP INT PRIMARY KEY,
    TenSP NVARCHAR(100),
    NgaySX DATE,
    DonGia DECIMAL(18, 2),
    MaNSX INT FOREIGN KEY REFERENCES HANGSX(MaNSX)
);

INSERT INTO HANGSX (MaNSX, TenHang) VALUES 
(1, N'Samsung'),
(2, N'Apple'),
(3, N'Sony'),
(4, N'LG'),
(5, N'Xiaomi');

INSERT INTO SANPHAM (MaSP, TenSP, NgaySX, DonGia, MaNSX) VALUES
(101, N'Galaxy S23', '2024-01-10', 21000000, 1),
(102, N'iPhone 15', '2024-02-05', 27000000, 2),
(103, N'Bravia X90J', '2023-12-15', 18000000, 3),
(104, N'LG Gram 2024', '2024-03-01', 32000000, 4),
(105, N'Mi 13 Pro', '2024-01-20', 16000000, 5);

