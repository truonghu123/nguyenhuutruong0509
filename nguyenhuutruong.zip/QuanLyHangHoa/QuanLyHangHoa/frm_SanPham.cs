﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyHangHoa
{
    public partial class frm_SanPham : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-HAFTC417\MAYCUATRUONG;Initial Catalog=QuanLyHangHoa;Integrated Security=True");
        public frm_SanPham()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            string query = "SELECT * FROM SANPHAM";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv_danhsach.DataSource = dt;
        }
        private void LoadHangSX()
        {
            string query = "SELECT * FROM HANGSX";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cb_hang.DataSource = dt;
            cb_hang.DisplayMember = "TenHang";
            cb_hang.ValueMember = "MaNSX";
            cb_hang.SelectedIndex = -1;
        }
        private void dtp_ngay_ValueChanged(object sender, EventArgs e)
        {
            int NgaySX = dtp_ngay.Value.Year;
            txt_nam.Text = (NgaySX + 2).ToString();
        }
        private void frm_SanPham_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadHangSX();
            dtp_ngay.ValueChanged += dtp_ngay_ValueChanged;
        }

        private void dgv_danhsach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_danhsach.Rows[e.RowIndex];

                txt_masp.Text = row.Cells["MaSP"].Value.ToString();
                txt_tensp.Text = row.Cells["TenSP"].Value.ToString();
                txt_dongia.Text = row.Cells["DonGia"].Value.ToString();
                cb_hang.SelectedValue = row.Cells["MaNSX"].Value.ToString();
                dtp_ngay.Value = Convert.ToDateTime(row.Cells["NgaySX"].Value);

                int NgaySX = dtp_ngay.Value.Year;
                txt_nam.Text = (NgaySX+2).ToString();
            }
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();

            SqlCommand cmd = new SqlCommand("INSERT INTO SANPHAM (MaSP, TenSP, NgaySX, DonGia, MaNSX) VALUES (@MaSP, @TenSP, @NgaySX, @DonGia, @MaNSX)", conn);
            cmd.Parameters.AddWithValue("@MaSP", txt_masp.Text);
            cmd.Parameters.AddWithValue("@TenSP", txt_tensp.Text);
            cmd.Parameters.AddWithValue("@NgaySX", dtp_ngay.Value);
            cmd.Parameters.AddWithValue("@DonGia", decimal.Parse(txt_dongia.Text));
            cmd.Parameters.AddWithValue("@MaNSX", cb_hang.SelectedValue);

            if (cmd.ExecuteNonQuery() > 0)
                MessageBox.Show("Đã thêm sản phẩm!");
            else
                MessageBox.Show("Thêm thất bại!");

            conn.Close();
            LoadData();
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Closed)
                conn.Open();

            SqlCommand cmd = new SqlCommand("UPDATE SANPHAM SET TenSP=@TenSP, NgaySX=@NgaySX, DonGia=@DonGia, MaNSX=@MaNSX WHERE MaSP=@MaSP", conn);
            cmd.Parameters.AddWithValue("@MaSP", txt_masp.Text);
            cmd.Parameters.AddWithValue("@TenSP", txt_tensp.Text);
            cmd.Parameters.AddWithValue("@NgaySX", dtp_ngay.Value);
            cmd.Parameters.AddWithValue("@DonGia", decimal.Parse(txt_dongia.Text));
            cmd.Parameters.AddWithValue("@MaNSX", cb_hang.SelectedValue);

            if (cmd.ExecuteNonQuery() > 0)
                MessageBox.Show("Đã cập nhật sản phẩm!");
            else
                MessageBox.Show("Cập nhật thất bại!");

            conn.Close();
            LoadData();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                SqlCommand cmd = new SqlCommand("DELETE FROM SANPHAM WHERE MaSP=@MaSP", conn);
                cmd.Parameters.AddWithValue("@MaSP", txt_masp.Text);

                if (cmd.ExecuteNonQuery() > 0)
                    MessageBox.Show("Đã xóa sản phẩm!");
                else
                    MessageBox.Show("Xóa thất bại!");

                conn.Close();
                LoadData();
            }
    }
}
