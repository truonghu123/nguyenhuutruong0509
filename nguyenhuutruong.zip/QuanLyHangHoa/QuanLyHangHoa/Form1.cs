﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyHangHoa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private frm_SanPham Form;
        private void openSanPhamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Form == null || Form.IsDisposed)
            {
                Form = new frm_SanPham();
                Form.MdiParent = this;
                Form.Show();
            }
            else
            {
                Form.BringToFront();
            }
        }

        private void closeSanPhamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.Close();
                Form = null; 
            }
        }
    }
}
